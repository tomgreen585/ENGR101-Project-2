// This program is copyright VUW.
// You may not distribute it in any way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.*;
import java.awt.Color;

/**
 * Question 4. Writing methods that use objects [10 marks]
 * 
 * Complete the animate() method so that you:
 *      1. Create a blue Hero named "Austin", at position 100, facing right.
 *      2. Create a slime named "Bo", at position 200, facing left.
 *      3. Make Austin introduce themself.
 *      4. Make Austin jump over the pit immediately to their right.
 *      5. Make Austin attack Bo.
 *      6. Make Bo attack Austin.
 *      7. Make Austin attack Bo a second time.
 *      8. Make Austin move right twice.
 *      9. Make Austin say "I can't jump that far"
 *      10. Make Austin move left.
 *              
 * NB: Austin will not actually fall into the pits if they move over them,
 *     but they need to jump over them for your answer to be correct.
 */
public class Program4 {

    // These will hold our characters
    private static Hero austin;
    private static Slime bo;

    /**
     * Animates two characters on the screen - a Hero and a Slime
     */
    public void animate() {
        UI.clearGraphics();
        this.drawBackground();
        
        /*# YOUR CODE HERE */
        this.austin = new Hero("blue", "Austin", 100);
        this.bo = new Slime("Bo", 200);

        austin.introduce();
        austin.jump();
        austin.attack(bo);
        bo.attack();
        austin.attack(bo);
        austin.move("right");
        austin.move("right");
        austin.say("I can't jump that far");
        austin.move("left");
        /*# END OF YOUR CODE */

    }

    /*********************************************
     * YOU CAN IGNORE EVERYTHING BELOW THIS LINE *
     *********************************************/
    public void setupGUI() {
        UI.initialise();
        UI.addButton("Run", this::animate);
        UI.setWindowSize(600,500);
        UI.setDivider(0.0);
        drawBackground();
    }

    public static void redraw() {
        austin.erase();
        bo.erase();
        drawBackground();
        austin.draw();
        bo.draw();
    }
    
    private static void drawBackground() {
        // Dirt
        UI.setColor(new Color(107,75,20));
        UI.fillRect(  0, 310, 110, UI.getCanvasHeight());
        UI.fillRect(140, 310, 145, UI.getCanvasHeight());
        UI.fillRect(365, 310, 30, UI.getCanvasHeight());
        UI.fillRect(425, 310, UI.getCanvasWidth() - 430, UI.getCanvasHeight());
        UI.setColor(new Color(87,55,0));
        UI.fillRect(  110, 290, 12, UI.getCanvasHeight());
        UI.fillRect(285, 290, 12, UI.getCanvasHeight());
        UI.fillRect(395, 290, 12, UI.getCanvasHeight());

        // Grass
        UI.setColor(new Color(25,128,61));
        UI.fillPolygon(new double[]{0,110,122,0}, new double[]{310,310,290,290},4);
        UI.fillPolygon(new double[]{140,285,297,152}, new double[]{310,310,290,290},4);
        UI.fillPolygon(new double[]{365,395,407,377}, new double[]{310,310,290,290},4);
        UI.fillPolygon(new double[]{425,UI.getCanvasWidth(),UI.getCanvasWidth(),437}, new double[]{310,310,290,290},4);

        // Water
        UI.setColor(new Color(53,40,200));
        UI.fillRect(110, 400, 30, UI.getCanvasHeight());
        UI.fillRect(285, 400, 80, UI.getCanvasHeight());
        UI.fillRect(395, 400, 30, UI.getCanvasHeight());
        UI.setColor(new Color(33,20,180));
        UI.fillPolygon(new double[]{110,140,140,122}, new double[]{400,400,380,380},4);
        UI.fillPolygon(new double[]{285,365,365,297}, new double[]{400,400,380,380},4);
        UI.fillPolygon(new double[]{395,425,425,407}, new double[]{400,400,380,380},4);
    }

    public static void main(String[] args){
        new Program4().setupGUI();
    }
}
