// This program is copyright VUW.
// You may not distribute it in any way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.*;

/**
 * Question 1. Getting User Input    [5 marks]
 *
 *  This method should ask the user for two values, and then add the two values
 *  together.
 * 
 *  Examples:
 *      First number: 5
 *      Second number: -1
 *      The sum is 4.0
 *      --------
 *      First number: 7
 *      Second number: 10
 *      The sum is 17.0
 */
public class Program1
{
    public void printSum() {
        /*# YOUR CODE HERE */
        double v1 = UI.askDouble("First number:");
        double v2 = UI.askDouble("Second number:");

        UI.println("The sum is " + (v1+v2));
        /*# END YOUR CODE */

    }

    /*********************************************
     * YOU CAN IGNORE EVERYTHING BELOW THIS LINE *
     *********************************************/
    public void setupGUI() {
        UI.initialise();
        UI.addButton("Run", this::printSum);
        UI.setWindowSize(500,500);
        UI.setDivider(1.0);
    }
    
    public static void main(String[] args) {
        new Program1().setupGUI();
    }
}
