// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.*;

/**
 * Question 1. Getting User Input    [5 marks]
 *
 *  This method should ask the user for two values, and then add the two values
 *  together.
 * 
 *  Examples:
 *      First number: 5
 *      Second number: -1
 *      The sum is 4.0
 *      --------
 *      First number: 7
 *      Second number: 10
 *      The sum is 17.0
 */
public class Program1
{
    public void printSum() {
        /*# YOUR CODE HERE */
