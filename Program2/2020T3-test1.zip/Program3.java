// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.*;
import java.awt.Color;

/**
 * Question 3. Defining a method with parameters.   [8 marks]
 * 
 * This class has two methods. The drawStack() method calls the drawBox(...) method to
 * draw two boxes stacked on top of each other.
 * 
 * (a) Complete the drawBox(...) method to draw a box. The box should be made of a coloured
 *     rectangle surrounded by a black outline.
 *
 * You will need to define five parameters: the position of the center of the box in (x,y) co-ordinates,
 * the width of the box, the height of the box, and the colour of the box.
 * 
 * (b) Complete the drawStack() method to draw four boxes by calling drawBox(...)
 * four times using different arguments. Your method should draw the stack shown in the
 * test handout.
 */
public class Program3 {
    
    /**
     * Draws a coloured box, with a black outline.
     *
     * You might find it useful to draw the filled part first, and the outline second.
     */
    public void drawBox(/*# YOUR CODE HERE */ ) {

        /*# YOUR CODE HERE */
    }

    /**
     * Draw a stack of boxes. [2 marks]
     *      The first box should red, be at (250,300), and be 150x75 pixels.
     *      The second box should blue, be at (265,225), and be 75x75 pixels.
     */
    public void drawStack() {
        UI.clearGraphics();
        this.drawBox(/*# YOUR CODE HERE */ );
        this.drawBox(/*# YOUR CODE HERE */ );
        this.drawBox(/*# YOUR CODE HERE */ );
        this.drawBox(/*# YOUR CODE HERE */ );
    } 

    /*********************************************
     * YOU CAN IGNORE EVERYTHING BELOW THIS LINE *
     *********************************************/
    public void setupGUI() {
        UI.initialise();
        UI.addButton("Run", this::drawStack);
        UI.setWindowSize(500,500);
        UI.setDivider(0.0);
    }
    
    public static void main(String[] args) {
        new Program3().setupGUI();
    }
}
