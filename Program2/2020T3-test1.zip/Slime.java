// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.UI;

import javax.imageio.ImageIO;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * A cute character that performs actions on the screen.
 *
 * <br/>
 * <strong>*** IMPORTANT ***</strong><br/>
 * You don't need to understand or change the code in this class.
 * The documentation tells you everything you need to know.
 * Wait until after the test to look at the source code!
 *
 * @author Morgan
 */
public class Slime
{
    private String name;

    // We need to keep track of the position on the screen
    // This is the *bottom-center* of the slime
    private double x = 100;
    private double y = 300.00;
    // We also track the position immediately before this one
    // so we know what area to erase when we're re-drawing
    private double oldX = 100.00;
    private double oldY = 300.00;

    // Are we facing right?
    // This is used to flip the slime if we're facing left
    private boolean right = false;

    /* These are arrays to store the slime data
     * This is a memory-intensive way to do things but
     * it stops us having to load the file from disk every frame
     */
    private BufferedImage[] attack;
    private BufferedImage[] die;
    private BufferedImage[] hurt;
    private BufferedImage[] idle;
    private BufferedImage[] move;

    //References to the current and previous frame
    private BufferedImage currentImage;
    private BufferedImage oldImage;

    // health
    private int health = 2;
    private boolean alive = true;

    /**
     * Creates a new Slime object with the specified name.
     *
     * The slime is drawn at the specified x position.
     */
    public Slime(String name, double position)
    {
        try {
            this.name = name;
            this.x = position;
            this.attack = new BufferedImage[5];
            this.die = new BufferedImage[4];
            this.hurt = new BufferedImage[4];
            this.idle = new BufferedImage[4];
            this.move = new BufferedImage[4];

            for(int i = 0; i < 4; i++){
                this.idle[i] = ImageIO.read(new File("sprites/slime-idle-" + i + ".png"));
                this.die[i] = ImageIO.read(new File("sprites/slime-die-" + i + ".png"));
                this.hurt[i] = ImageIO.read(new File("sprites/slime-hurt-" + i + ".png"));
                this.move[i] = ImageIO.read(new File("sprites/slime-move-" + i + ".png"));
            }
            for(int i = 0; i < 5; i++){
                this.attack[i] = ImageIO.read(new File("sprites/slime-attack-" + i + ".png"));
            }
            this.currentImage = idle[0];
            this.oldImage = currentImage;
            this.draw();
        } catch (IOException e) {
            UI.println("Error reading file: " + e.getMessage());
        }
    }

    /**
     * Makes slime attack
     */
    public void attack() {
        for(int i = 0; i < attack.length; i++) {
            this.updateSlime(attack[i],x,y);
        }
        this.updateSlime(idle[0],x,y,false);
    }

    /**
     * Makes the slime take damage
     */
    public void damage() {
        for(int i = 0; i < hurt.length; i++) {
            this.updateSlime(hurt[i],x,y);
        }
        health--;
        if(health <= 0) {
            this.die();
        }
        this.updateSlime(idle[0], x, y, false);
    }

    /**
     * Makes the slime run its death animation
     */
    private void die() {
        for(int i = 0; i < die.length; i++) {
            this.updateSlime(die[i], x, y);
        }
        alive = false;
        UI.eraseImage(oldImage, oldX-oldImage.getWidth()/2, oldY-oldImage.getHeight()-1);
    }
    
    /*
     * This updates the character on the screen (but actually just passes it to the other method)
     */
    private void updateSlime(BufferedImage image, double newX, double newY){
        this.updateSlime(image, newX, newY, true);
    }
    
    /*
     * This erases the old image and replaces it with a new image. It also updates x and y.
     * 
     * If delay is true, we pause for a bit here. This is important, otherwise everything would
     * happen much too quickly and we wouldn't see it.
     */
    private void updateSlime(BufferedImage image, double newX, double newY, boolean delay) {
        if (this.alive) {
            this.oldImage = currentImage;
            this.currentImage = image;
            this.oldX = this.x;
            this.oldY = this.y;
            this.x = newX;
            this.y = newY;
            Program4.redraw();
            if (delay) {
                UI.sleep(100);
            }
        }
    }
    
    /*
     * Draw the slime on the screen
     */
    public void draw() {
        if (alive) {
            // Then we need to check which direction we're facing
            if (right) {
                // If we're facing right, just draw the slime
                UI.drawImage(currentImage, x - currentImage.getWidth() / 2, y - currentImage.getHeight() - 1);
            } else {
                // We're facing left, and the character is facing right
                // We need to do some magic to flip them around
                AffineTransform flip = new AffineTransform();
                // If we scale the image by (-1,1), it reflects it along the vertical axis
                flip.concatenate(AffineTransform.getScaleInstance(-1, 1));
                // But now we need to move it back into the right position
                flip.concatenate(AffineTransform.getTranslateInstance(-currentImage.getWidth(), 0));
                // Turn it into something we can apply to an image (the JavaDocs have more info)
                AffineTransformOp op = new AffineTransformOp(flip, AffineTransformOp.TYPE_BILINEAR);
                // Flip the image and draw it
                UI.drawImage(op.filter(currentImage, null), x - currentImage.getWidth() / 2, y - currentImage.getHeight() - 1);
            }
        }
    }

    public void erase() {
        UI.eraseImage(oldImage, oldX-oldImage.getWidth()/2, oldY-oldImage.getHeight()-1);
    }
}
