// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.*;

/**
 * Question 2. Writing programs with if.    [12 Marks]
 */
public class Program2
{
    /**
     *  (a) Temperature Converter [4 marks]
     *
     *  Shui is baking a cake for their friend's birthday, but the recipe is from an American website and all the temperatures are in Fahrenheit.
     *  
     *  Help Shui by writing a method that can convert between Fahrenheit and Celsius.
     *  
     *  The user will provide the temperature (as a double), and the units (as a string, which will be "C" or "F").
     *  If the user inputs the temperature in Celsius, your method should calculate and print the temperature in Fahrenheit.
     *  Otherwise, assume the temperate is in Fahrenheit, and your method should calculate and print the temperature in Celsius.
     *  
     *  The formulae for the conversions are given below:
     *      f = (c * 9.0/5.0) + 32;
     *      c = (f - 32) * 5.0/9.0;
     *      
     *  For example, if the user inputs 19.5 and "C", you would use the first equation:
     *      (19.5 * 9.0/5.0) + 32 = 67.1°F
     *  
     *  Examples:
     *  
     *  INPUT (Freezing point of water):
     *      Temperature: 0
     *      Units (C or F): C
     *  OUTPUT:
     *      0.0°C is 32.0°F
     *      
     *  INPUT (Minimum temperature for a fever):
     *      Temperature: 100.4
     *      Units (C or F): F
     *  OUTPUT:
     *      100.4°F is 38°C
     *      
     */
    public void temperatureConverter() {
        double inputTemp = UI.askDouble("Temperature:");
        String inputUnits = UI.askString("Units (C or F):");

        /*# YOUR CODE HERE */

    }

    /**
     * (b) calculateOrderPrice [8 marks]
     *
     * Vivian runs an online store that sells very high-quality stickers. They want customers
     * to buy lots at a time, so they have decided to apply a discount to orders over a certain
     * amount.
     *
     * Each sticker normally costs $0.99. The discounts are as follows:
     *
     *      Quantity | Discount
     * --------------+--------------
     *  100 or fewer | Base price
     *     101 - 300 | 5% discount
     *     301 - 500 | 10% discount
     *         > 500 | 15 % discount
     * 
     *
     * Complete the calculateOrderPrice method below.
     * The method asks the user for the quantity of the order, and should then calculate the
     * total cost, using the discount table above.
     *
     * EXAMPLES:
     *
     *     Enter quantity: 100
     *     The total cost is $99.00
     *
     *     Enter quantity: 101
     *     The total cost is $94.99
     */
    public void calculateOrderPrice() {

        double quantity = UI.askDouble("Enter quantity:");
        double itemPrice = 0.99;
        double totalCost = 0.0;

        /*# YOUR CODE HERE */

        UI.printf("The total cost is $%.2f\n", totalCost);
    }

    /*********************************************
     * YOU CAN IGNORE EVERYTHING BELOW THIS LINE *
     *********************************************/
    public void setupGUI() {
        UI.initialise();
        UI.addButton("(a) temperatureConverter", this::temperatureConverter);
        UI.addButton("(b) calculateOrderPrice", this::calculateOrderPrice);
        UI.setWindowSize(500,500);
        UI.setDivider(1.0);
    }

    public static void main(String[] args) {
        new Program2().setupGUI();
    }
}
