// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP102 - 2020T3, Final Examination
 * Name:
 * Username:
 * ID:
 */

 

import ecs100.*;

import java.awt.*;
import java.util.ArrayList;

/**
 * Question 5. Writing methods with for.
 *
 * This program should plot and do analysis on temperature data.
 * 
 * The analyseTemperatures() method is done for you. It asks the user for a sequence of temperatures
 * and saves the values in an ArrayList. It then calls two methods that you must complete.
 * 
 * (a) [5 marks] Complete the findAverage(...) method to find and return the average temperature.
 * 
 * (b) [10 marks] Complete the plotTemperatures(...) method to plot a line graph of the values on
 * the graphics pane with a red line indicating the average value. The code to draw the axes has been
 * done for you -- note that the Y value can be positive and negative.
 *
 *  - Draw the points every 50 units along the X axis, plotting the values on the Y axis.
 *  - You should start the plot from the origin. You may assume the user enters between 1
 *    and 9 values, and all numbers are in the range of [-50.0, 50.0].
 *  - Draw a red line for the average value
 */
public class Program5
{
    /**
     * Constants
     */
    private static final double X_ORIGIN = 50;
    private static final double Y_ORIGIN = 100;
    private static final double STEP = 50;
    
    public void analyseTemperatures () {
        ArrayList<Double> temperatures = UI.askNumbers("Enter numbers [-50.0 to 50.0]");
        UI.println("The average temperature is " + this.findAverage(temperatures));
        this.plotTemperatures(temperatures);
    }
    
    public double findAverage(ArrayList<Double> temperatures) {
        double average = 0.0;

        /*# YOUR CODE HERE */

        return average;
    }
    
    public void plotTemperatures(ArrayList<Double> temperatures) {
        UI.clearGraphics();
        // Y Axis ranges from -50 to 50, with 0 at 100 pixels (Y_AXIS)
        UI.drawLine(X_ORIGIN, Y_ORIGIN -50, X_ORIGIN, Y_ORIGIN +50);
        // X Axis ranges from 0 to 450 (maximum pf 9 values), and starts at 50 pixels (X_AXIS)
        UI.drawLine(X_ORIGIN, Y_ORIGIN, X_ORIGIN + 9*STEP, Y_ORIGIN);
        // Find the average so we can draw it later
        double average = findAverage(temperatures);

        /*# YOUR CODE HERE */

        // Finally, draw the red line indicating the average temperature
        UI.setColor(Color.RED);
        /*# YOUR CODE HERE */

    }
    
    /*********************************************
     * YOU CAN IGNORE EVERYTHING BELOW THIS LINE *
     *********************************************/
    public void setupGUI() {
        UI.initialise();
        UI.addButton("Run", this::analyseTemperatures);
        UI.setWindowSize(800,500);
        UI.setDivider(0.3);
    }
    
    public static void main(String[] args) {
        new Program5().setupGUI();
    }
}
